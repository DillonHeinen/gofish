1. Navigate to folder containing files.
2. Type make into linux terminal.
3. Run ./gofish.
4. Check gofish_results in source code file for results.